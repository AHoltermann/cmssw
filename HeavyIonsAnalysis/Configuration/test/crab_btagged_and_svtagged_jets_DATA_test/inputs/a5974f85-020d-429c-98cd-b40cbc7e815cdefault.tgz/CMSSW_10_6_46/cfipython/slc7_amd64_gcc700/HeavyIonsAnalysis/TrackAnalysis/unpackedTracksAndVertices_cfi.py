import FWCore.ParameterSet.Config as cms

unpackedTracksAndVertices = cms.EDProducer('TrackAndVertexUnpacker',
  packedPFCandidates = cms.InputTag('packedPFCandidates'),
  lostTracks = cms.InputTag('lostTracks'),
  primaryVertices = cms.InputTag('offlineSlimmedPrimaryVertices'),
  secondaryVertices = cms.InputTag('slimmedSecondaryVertices')
)
