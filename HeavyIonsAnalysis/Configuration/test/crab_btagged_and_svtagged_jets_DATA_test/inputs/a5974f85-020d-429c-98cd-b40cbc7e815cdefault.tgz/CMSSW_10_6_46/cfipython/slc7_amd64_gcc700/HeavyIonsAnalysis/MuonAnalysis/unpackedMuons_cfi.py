import FWCore.ParameterSet.Config as cms

unpackedMuons = cms.EDProducer('MuonUnpacker',
  muons = cms.InputTag('slimmedMuons'),
  tracks = cms.InputTag('unpackedTracksAndVertices'),
  primaryVertices = cms.InputTag('unpackedTracksAndVertices'),
  beamSpot = cms.InputTag('offlineBeamSpot'),
  muonSelectors = cms.vstring(
    'AllTrackerMuons',
    'TMOneStationTight'
  ),
  addPropToMuonSt = cms.bool(False)
)
