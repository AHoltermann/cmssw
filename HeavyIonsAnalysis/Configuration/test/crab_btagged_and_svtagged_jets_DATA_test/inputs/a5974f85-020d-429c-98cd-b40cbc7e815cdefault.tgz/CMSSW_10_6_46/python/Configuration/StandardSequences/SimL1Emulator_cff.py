import FWCore.ParameterSet.Config as cms

from L1Trigger.Configuration.SimL1Emulator_cff import *

# make trigger digis available under with the raw2digi names
from Configuration.Eras.Modifier_fastSim_cff import fastSim
def _fastSimTriggerDigis(process):
    # pretend these digis have been through digi2raw and to the HLT internal raw2digi, by using the approprate aliases
    # consider moving these mods to the HLT configuration
    from FastSimulation.Configuration.DigiAliases_cff import loadTriggerDigiAliases
    loadTriggerDigiAliases(process)
modifySimL1Emulator_fastSimTriggerDigis = fastSim.makeProcessModifier(_fastSimTriggerDigis)
