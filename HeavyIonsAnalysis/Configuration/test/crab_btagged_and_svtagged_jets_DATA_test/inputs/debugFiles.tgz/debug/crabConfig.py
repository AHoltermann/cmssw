from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = 'btagged_and_svtagged_jets_DATA_test'
config.section_('JobType')
config.JobType.psetName = 'recipe_dataunpacked.py'
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.JobType.maxMemoryMB = 2300
config.section_('Data')
config.Data.inputDataset = '/HighEGJet/Run2017G-UL2017_MiniAODv2-v2/MINIAOD'
config.Data.totalUnits = -1
config.Data.unitsPerJob = 50000
config.Data.splitting = 'EventAwareLumiBased'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/group/phys_heavyions/aholterm/g2qqbar'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
